import ride1 from '../assets/ride1.jpg';
import ride2 from "../assets/ride2.jpg";
import person1 from "../assets/person1.jpeg"
import person2 from "../assets/person2.jpeg"
import person3 from "../assets/person3.jpeg"
import teamrapido from "../assets/teamrapido.jpeg";
import {BrowserRouter,Route,Routes,Link} from 'react-router-dom'
import "aos/dist/aos.css"
import { useEffect } from 'react';
import AOS from "aos";
function About(){
   
      useEffect(() => {
  AOS.init({
    duration: 1000,
    once: true,
  });
}, []);
    return(
        <>
        <div className="container-fluid-lg mx-5" >
            <div className="row justify-content-center mt-5">
                <div className=" col-12 col-md-5 m-2  " data-aos="fade-right">
                   <div className="container-item">
                     <h1 className="head">India’s Beloved
                         <h1 className="headspan" >Bike Taxi Service</h1></h1>
                         <p className="para1">We are not an option, we are a choice</p>
                         <p className="para2">We're #1 choice of 10 Million people because we're the solution of India's intra-city commuting problems. With assured safety, we also provide economically priced rides.</p>
                         <p className="para1">
                            What makes us different?
                         </p>
                         <p className="para2">Our bike taxis can dodge the traffic during peak hours and get you to the destination in a jiffy! So when you think travel, think Rapido.</p>
                    </div>


                </div>
                    <div className=" col-12 col-md-6 m-2"  data-aos='fade-left' style={{overflow:'hidden'}}>
                        <div className="box-container m-5">
                             <div className="box box-1 " >
                            <img src={ride1} className='img1' />
                              </div>
                             <div className="box box-2 m-1  "  >
                              <img src={ride2} className='img2'  />

                              </div>
                        </div>
                     </div>
                      <div className='container-fluid-lg mx-5 container2'>
            <div className='row justify-content-center secondrow'>
                <div className="col-12 col-md-5 m-2 seconddiv"style={{overflow:'hidden'}} data-aos="fade-down">
                    <h3 className='h3 overflow-hidden'>Champions of our success story</h3>
                    <p className='para2'>Rapido has come a long way ever since its inception in 2015. With a lot of hardwork and perseverance we have made a place for ourselves in the market. As a brand and as a service, it is our constant endeavour to redefine ourselves.</p>
                </div>
                <div className="col-12 col-md-6 m-2">
                    <div className='inner-container'>
                    <div className='' style={{overflow:'hidden'}}>
                        <img src={person1} alt=""  className='personimg' data-aos="fade-up"/>
                    <h5 className='h5' data-aos="fade-up">Nakshathra </h5>
                    <h6 data-aos="fade-up">Founder</h6>
                    </div>       
                    <div style={{overflow:'hidden'}}>
                        <img src={person2} alt=""className='personimg' data-aos="fade-up" />
                    <h5 className='h5' data-aos="fade-up"> Rishikesh S R 
                    </h5> <h6 className='' data-aos="fade-up">Founder</h6>
                    </div>
                    <div style={{overflow:'hidden'}}>
                         <img src={person3} alt=""className='personimg' data-aos="fade-up"/> <br />
                    <h5 className='h5' data-aos="fade-up">Aravind Sanka</h5> <h6 data-aos="fade-up">Founder</h6>
                    </div>
                   
                    </div>
                </div>
            </div>
        </div>
            </div>
             </div>
      <div className=' thirddev' style={{  backgroundImage: `url(${teamrapido})`}} data-aos="zoom-in-down">
         <h1 className='thirdh1'data-aos="fade-down">Jobs @ Rapido</h1>
         <p className='thirdp p-3' data-aos="fade-down">Join us in exploring a world of endless opportunities. Let’s find a spot for you.</p>
         <button className='btn  p-3 workbtn '>Work with us</button>
      </div>
        </>
    )
}
export default About
// ----------------------footer-------------
   export function Aboutchild(props){
    return(
        <>
        <div className='footer'>
  <div className='container-fluid footer-container mt-5 '>
    <div className='row'>
      <div className="col-12 col-md-3 footer-col1 ">
        <div className='container fcon'>
            <div className='row'>
                <div className="col-md-5 col-12">
                    <h6 className='footer-h6'>Customer App</h6>
                     <button className='btn footer-btn'><i className="fa-brands fa-google-play"></i> Google Play</button>
                     <button className='btn footer-btn'><i className="fa-brands fa-apple"></i> App Store</button>
                </div>
                <div className="col-md-5 col-12">

                    <h6 className='footer-h6'>Captain App</h6>
                    <button className='btn footer-btn footerrbtn'><i className="fa-brands fa-google-play"></i> Google Play</button>
                </div>
            </div>
        </div>
      </div>

      <div className="col-12 col-md-2 footer-col2">
        <div>
           <h6 style={{cursor:"pointer"}}>Home</h6>
           <h6>About Us</h6>
           <h6>Safty</h6>
           <h6>Blog</h6>
           <h6>Contact Us</h6>
        </div>
      </div>
      <div className="col-12 col-md-2 footer-col3">
        <h6>Customer Terms - Bike Taxi</h6>
        <h6>Customer Terms - Cabs and Auto</h6>
        <h6>Corporate Affairs</h6>
      </div>
      <div className="col-12 col-md-2 footer-col4 ">
           <h6>Customer Terms - Bike Taxi</h6>
        <h6>Customer Terms - Cabs and Auto</h6>
        <h6>Corporate Affairs</h6>
      </div>
      <div className="col-12 col-md-2 footer-col5 ">
        <h6 className='footer-h6'>Follow Us</h6>
        <div className='icons'>
        <i className="fa-brands fa-facebook-f fa-icons"></i>
        <i className="fa-brands fa-twitter fa-icons"></i>
        <i className="fa-brands fa-linkedin-in fa-icons"></i>
       <i className="fa-brands fa-instagram fa-icons"></i>
       </div>
      </div>
    </div>
    <hr />
    <p className='text-center footer-p'>© 2025 Roppen Transportation. All rights reserved.</p>
  </div>
</div>

        </>
    )
   }
       