import blog1 from "../assets/blog-1.jpeg"
import blog2 from "../assets/blog-2.jpeg"
import blog3 from "../assets/blog-3.jpeg"
import blog4 from "../assets/blog-4.jpeg"
import blog5 from "../assets/blog-5.jpg"
import blog6 from "../assets/blog-6.jpeg"
import blog7 from "../assets/blog-7.jpg"
import blog8 from "../assets/blog-8.jpeg"
import blog9 from "../assets/blog-9.jpg"
import "aos/dist/aos.css"
import { useEffect } from 'react';
import AOS from "aos";
function Secondblog({ img, para1, para2, title,Updated }) {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true,
    });
  }, []);
  return (
    <>
    
    <div className="card h-100 blog-card" >
      <img src={img} className="card-img-top blog-img" alt="blog" data-aos="fade-down-right" />
      <div className="card-body">
        <p className="card-para" data-aos="fade-down-left">{para1}</p>
        <h5 className="card-title" data-aos="fade-down-left">{title}</h5>
        <p className="card-text" data-aos="fade-down-left">{para2}</p>
      </div>
    </div>
    </>
  )
}

export function Blogsecond() {
  const Blog1 = [
    {
      img: blog1,
      para1: "Jan 21st,2021",
      title:
        "Make Commute Hassle Free – Business Travel Show reports a win-win solution for travel managers and employees",
      para2:
        "A survey published by the Business Travel Show found that 58 percent of business travel buyers agree that alternative transport providers such as Rapido are a good option for business travel...",
      
    },
    {
      img: blog2,
      para1: "Feb 28th 2021",
      title: "Boost Business Productivity with these Tips",
      para2:"Boost Business Productivity with these TipsHere are 5 ways to boost business productivity: 1. Get rid of clutter, and take care of your workplace environment The most straightforward way is to tidy up the office space. Studies [https://www.sciencedirect.com/science/article/abs/pii/S0360132318307157] have demonstrated that our physical environment has a significant effect on the way that we work, think and behave. When the environment is in a mess, so are we. Clutter can also affect general mental health [https://www.nytimes.com/2019/01"
    },
    {
      img: blog3,
      para1: "Mar 10th 2021",
      title: "Traveler first Business Travel Program",
      para2: "When your employees travel for work, do they find your company’s travel program more of a help or a hindrance? If it’s the latter, it’s time you considered some adjustments that can make a significant impact. In this post, we’ll look at four hallmarks of business travel programs that can work for both your control, while also respecting the long hours, rushed pace, and often challenging life of your business travelers."
    },
    {
      img: blog4,
      para1: "Apr 15th 2021",
      title: "Make Commute Hassle Free",
      para2: "Customise your commute program to address your employees travel needs If time is money, then wasted time is wasted money. The kind of time-wasting activities we’re talking about here are explicit work-related activities that you don’t even realise are costing your business money. We’re talking about mundane admin tasks which add no value — the bane of every company."
    },
     {
      img: blog5,
      para1: "Aug 15th 2022",
      title: "Delight your Customers with this",
      para2: "Delight your customers with this! It’s time to reach the new customers and give them the importance they deserve. Keeping convenience at the core, we came up with Rapido Coupon [https://rapido.bike/CorporatePartners?utm_source=medium&utm_medium=article&utm_campaign=coupons] s to significantly speed up the process of coordinating courtesy rides for customers and guests, especially for companies in the service sector."
    },
     {
      img: blog6,
      para1: "Jun 15th 2023",
      title: "Help your Business Grow and Travel Faster",
      para2: "We built Rapido Corporate [https://rapido.bike/CorporatePartners?utm_source=ownwebsite&utm_medium=blog&utm_campaign=article] to help organisations perfect the way they move the people that matter to them. And while our initial focus was on driving business travel efficiency through features like monthly billing and reporting, it didn’t take long before we realised that organisations needed Rapido for a lot more."
    },
     {
      img: blog7,
      para1: "May 15th 2024",
      title: "HELMET AWARENESS CAMPAIGN BY RAPIDO",
      para2: "Research shows that two- wheeler riders reduce their risk of head injuries by 80 percent when they wear helmets. Most of the deaths and critical injuries reported in two-wheeler accidents are that the riders do not wear helmets and to increase awareness among the two wheeler riders, Rapido – India’s largest bike taxi [https://play.google.com/store/apps/details?id=com.rapido.passenger] took this great CSR initiative of a helmet awareness ."
    },
     {
      img: blog8,
      para1: "Feb 28th 2025",
      title: "Rapido takes the spotlight at popular co-working spaces in Gurugram",
      para2: "Co-working spaces have created a niche ecosystem in the start-up industry. Last week, Rapido marked its presence in innovative co-working spaces like GoWork, Springboard, GoHive, Ikeva and The Office Pass by organising a customer registration drive at these sprawling campuses. People generally look at discovering ways and means to avoid peak hour congestion. But then, the chance of finding a four-wheeler cab service on time is a rare phenomenon. "
    },
     {
      img: blog9,
      para1: "Oct 31th 2025",
      title: "Breaking gender stereotypes",
      para2: "Achieving a gender-equal world starts by making sure women’s needs/experiences are well integrated in the field of technology and innovations. Rapido believes that women can make a huge impact and here we give a big shout out to one of our woman captain - Manjula who started off her journey with Rapido as recent as last week and has gained popularity already. A 23 year old, based out of Bangalore - Manjula joined Rapido as a Captain on October 30, and on her very first day completed 7 rides."
    }
  ]

  return (
    <div className="container my-4">
      <div className="row g-4">
        
        {Blog1.map((item, index) => (
          <div className=" col-lg-4 col-md-2" key={index}>
            <Secondblog
              img={item.img}
              para1={item.para1}
              title={item.title}
              para2={item.para2}
            />
          </div>
        ))}
      </div>
    </div>
  )
}

function Blog() {
  return (
    <>
     <h1 className="blog-h1" data-aos="flip-left">Blog</h1>
      <Blogsecond />
    </>
  )
}

export default Blog
