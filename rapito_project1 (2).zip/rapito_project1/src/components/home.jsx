import bike from '../assets/bike.jpeg'
import auto from '../assets/autoshare.jpeg'
import shareauto from '../assets/auto.jpeg'
import parcel from '../assets/parcel.jpeg'
import cab from '../assets/cap.jpeg'
import cabpre from '../assets/cappre.jpeg'
import home1 from '../assets/blog-1.jpeg'
import home2 from '../assets/blog-2.jpeg'
import home3 from "../assets/home3.avif"
import home4 from "../assets/blog-4.jpeg"
import home5 from "../assets/home2.avif"
import money1 from '../assets/homemoney.avif'
import money2 from '../assets/homemoney2.jpg'
import money3 from '../assets/homemoney3.jpeg'
import money4 from '../assets/homemoney4.jpeg'
import imgapp1 from '../assets/rapido-app.jpeg'
import imgapp2 from '../assets/rapido-app2.png'
import "aos/dist/aos.css"
import { useEffect } from 'react';
import AOS from "aos";
function Home(){
  useEffect(() => {
      AOS.init({
        duration: 1000,
        once: true,
      });
    }, []);
    return (
        <>
        {/* section home */}
<section id="home">
   <form className="main-form my-5 mx-auto" style={ {width:'50%'}}data-aos="fade-down">
    <div className='home-nav-div'>
    <h2 className="head head-head2" data-aos="zoom-in-up">Bharat Moves On Rapido!</h2>

  <div className="mb-3" style={{overflow:"hidden"
  }}>
    <div className="input-group mb-3" style={{width: "50%;", overflow:"hidden"}}data-aos="zoom-in-up">
  <span className="input-group-text"><i className="fa fa-location-dot"></i></span>
  <input type="email" className="form-control" placeholder="Enter Pickup location"data-aos="zoom-in-up" style={{overflow:"hidden"}}/>
</div>
    
  </div>
  <div className="mb-3"data-aos="zoom-in-down">
    
    <div className="input-group mb-3" style={{width: "50%;"}} data-aos="zoom-in-down">
  <span className="input-group-text"><i className="fa-solid fa-location-crosshairs"></i></span>
  <input type="email" className="form-control" placeholder="Enter Pickup location"data-aos="zoom-in-down"/>
</div>


  </div>

  <button type="submit" className="btn btn-submit" style={{backgroundColor:" rgba(243, 179, 62, 1)", color:"white"}}>Book Ride</button>
  </div>
</form>
</section>
<section className='service-home'> 
 <h1 className='home-h1' data-aos="fade-up-left"> Services</h1>
<Homesecond/>
<div className="container-fluid-lg mx-5" style={{overflow:"hidden"}}>
            <div className="row justify-content-center mt-5"style={{backgroundColor:"rgb(227, 246, 253)", overflow:"hidden"}}  data-aos="flip-left"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="1000">
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
  <h1 className='home-head-h1'>Get Quick Rides, <span className="Span-head"  data-aos="zoom-in">Low</span> Fares</h1>
  <p className='home-para' data-aos-duration="3000"data-aos="zoom-out">In Rapido we ensure our customers get rides quickly at the most affordable prices.</p>
  <button className='btn home-btn' data-aos="zoom-in" data-aos-duration="3000">Book a ride <i class="fa-solid fa-arrow-right-long" ></i></button>
                   </div>
                </div>
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
                        <div className="container-fluid-lg ">
                          <div className="row justify-content-center mt-5">
                             <div className=" col-12 col-md-5 m-2  " >
                                <img src={home1} alt="" className='img-home-second'data-aos="zoom-in" data-aos-duration="3000"/>
                                <img src={home5} data-aos="zoom-in" data-aos-duration="3000"alt="" className='img-home-second'/>
                             </div>
                             <div className=" col-12 col-md-5 m-2  " >
                                <img src={home3} data-aos="zoom-out"alt="" className='img-home-second' data-aos-duration="3000"/>
                                <img src={home4}data-aos="zoom-out" alt="" className='img-home-second' data-aos-duration="3000"/>
                             </div>
                          </div>
                        </div>
                   </div>
                </div>
              </div>
</div>

<div className="container-fluid-lg mx-5" style={{overflow:"hidden"}}>
            <div className="row justify-content-center mt-5"style={{backgroundColor:"rgb(227, 246, 253)"}} data-aos="flip-right"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="1000">
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
                        <div className="container-fluid-lg ">
                          <div className="row justify-content-center mt-5">
                             <div className=" col-12 col-md-5 m-2  " >
                                <img src={money1} alt="" className='img-home-second'data-aos="zoom-in" data-aos-duration="3000" />
                                <img src={money2} alt="" className='img-home-second' data-aos="zoom-in" data-aos-duration="3000"/>
                             </div>
                             <div className=" col-12 col-md-5 m-2  " >
                                <img src={money3} alt="" className='img-home-second'data-aos="zoom-out"data-aos-duration="3000"/>
                                <img src={money4} alt="" className='img-home-second 'data-aos="zoom-out"data-aos-duration="3000"/>
                             </div>
                          </div>
                        </div>
                   </div>
                </div>
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
  <h1 className='home-head-h1' data-aos="zoom-in">Flexible Hours & High Earnings </h1>
  <p className='home-para' data-aos-duration="3000"data-aos="zoom-out">Join as a Rapido captain and earn on your own terms. Driver whenever you want.</p>
  <button className='btn home-btn' data-aos="zoom-in" data-aos-duration="3000"> Start Earning <i class="fa-solid fa-arrow-right-long" ></i></button>
                   </div>
                </div>
              </div>
</div>
<div className="container-fluid-lg mx-5" style={{overflow:"hidden"}}>
            <div className="row justify-content-center mt-5"style={{backgroundColor:"rgb(227, 246, 253)"}} data-aos="flip-left"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="1000">
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
  <h1 className='home-head-h1' data-aos="zoom-in">Safety for all </h1>
  <p className='home-para' data-aos-duration="3000"data-aos="zoom-out">At Rapido, your safety is our priority. We’re dedicated to making every ride safe and comfortable.</p>
  <button className='btn home-btn' data-aos="zoom-in" data-aos-duration="3000">Know More </button>
                   </div>
                </div>
                <div className=" col-12 col-md-5 m-2  fourth-home-div " >
                  <img src={home2} alt="" 
                  data-aos="zoom-in" className='fourth-home'data-aos-duration="3000" />
                </div>
              </div>
</div>
<div className='last-div'>
<h1 className='last-h1' data-aos="fade-right">Download Now</h1>
<img src={imgapp2} data-aos="flip-up"alt="" className='last-img'/>
<img src={imgapp1} data-aos="flip-up" alt="" className='last-img'/>
<h3 className='last-h3' data-aos="fade-left">Rapido: Bike-Taxi,Auto & Cabs</h3>
<h3 className='last-h3 hello ' data-aos="fade-left">Rapido Captain: Drive & Earn</h3>
</div>
<hr />
<div  className='last-div-2'>
  <i class="fa-solid fa-x last-i" data-aos="zoom-out-up"></i>
  <i class="fa-brands fa-youtube last-i" data-aos="zoom-out-down" ></i>
 <i class="fa-brands fa-square-instagram last-i" data-aos="zoom-out-up"></i>
</div>
<hr style={{marginBottom:"70px"}}/>
</section>
{/* section service */}
        </>
    )
}

export default Home

 function Services({img,title}){
  return(
  <>
  <section id="service" className="container my-5" >
<div className="card h-100 blog-card" data-aos="fade-down-left">
      <img src={img} className="card-img-top home-img" alt="blog" data-aos="fade-down-right"/>
      <div className="card-body">
        <h5 className="card-title"  data-aos="zoom-in">{title}</h5>
        </div>
        </div>
</section></>
  )
  }
  export function Homesecond(){
    const Secondhome=[
      {
        img:bike,
        title:"Bike"
      },
      {
        img:auto,
        title:"Auto"
      },
      {
        img:shareauto,
        title:"Share Auto"
      },
      {
        img:parcel,
        title:"Parcel"
      },
      {
        img:cab,
        title:"Cab Economy"
      },
      {
        img:cabpre,
        title:"Cab Premimum"
      }
    ]
    return(
      <>
      <div className="container my-4">
      <div className="row g-4">
        {Secondhome.map((item,index)=>(
          <div className=" col-lg-3 col-md-2 second-home-col" key={index}>
          <Services 
          img={item.img}
          title={item.title}
          />
      </div>
        ))}
       </div>
       </div>
      </>
    )
  }

