import "aos/dist/aos.css"
import { useEffect } from 'react';
import AOS from "aos";
function Contact(){
    useEffect(() => {
        AOS.init({
          duration: 1000,
          once: true,
        });
      }, []);
    return(<> 
    <h1 className="contact-h1" data-aos="fade-left">You can fill us here...</h1>
    <p className="contact-para" data-aos="fade-right"> Find help for your queries here:</p>
        <div className="container my-4 ">
           <div className="row g-4">
               <div className=" col-lg-8 col-md-2" >
                <form>
                  <div className="mb-3">
                   <label  className="form-label required" data-aos="fade-right">Name</label>
                   <input type="name" className="form-control" id="exampleInputEmail1" placeholder="Enter Name" div data-aos="fade-left"  required/>
                  </div>
                  <div className="mb-3">
                   <label  className="form-label required" data-aos="fade-right">Email address</label>
                    <input type="email" placeholder="Enter your email" className="form-control" id="exampleInputPassword1" div data-aos="fade-left" required/>
                 </div>
                  <div className="mb-3">
                   <label  className="form-label required" data-aos="fade-right">Mobile Number</label>
                    <input type="number" placeholder="Enter your Mobile numbe" className="form-control" id="exampleInputPassword1" div data-aos="fade-left" required/>
                 </div>
                    {/* Dropdown (new field) */}
              <div className="mb-3">
                <label className="form-label required" data-aos="fade-right">You are a</label >
                <select className="form-select" div data-aos="fade-left" required>
                  <option value="">-- Select --</option>
                  <option value="support">Captain</option>
                  <option value="feedback">customer</option>
                  <option value="others">Others</option>
                </select>
              </div>
                 <div class="mb-3">
  <label  class="form-label required"div data-aos="fade-right">Comment</label>
  <textarea class="form-control " id="exampleFormControlTextarea1" rows="5" required placeholder="Enter your comment" div data-aos="fade-left"></textarea >
</div>
  <button type="submit" className="btn contact-btn" data-aos="zoom-in-down">Submit</button>
</form>
                </div>
                <div className=" col-lg-4 col-md-2 contact-div-2 " >
                 <div className="conatact-div" >
                    <h6 className="contact-second-h6" data-aos="zoom-out-down">Registered Officce Address</h6>
                    <p className="contact-second-p" data-aos="zoom-in-left">Roppen Transportation Services Pvt Ltd, 3rd Floor, Sai Prithvi Arcade, Megha Hills, Sri Rama Colony, Madhapur, Hyderabad - 500081</p> 
                    <p data-aos="zoom-in-left">CIN:U52210TG2015PTC097115</p><br /><br /><br />
                    <h6 className="contact-second-h6" data-aos="zoom-out-down">City Office:</h6>
                    <p className="contact-second-p" data-aos="zoom-in-left">Roppen Transportation Services Pvt Ltd, #148, 1st Floor, SLV Nilaya, 5th Main 80ft road, HSR Layout 7th Sector, Bangalore 560102.</p> <br /><br /><br />
                    <h6 className="contact-second-h6" data-aos="zoom-out-down">Corporate Office:</h6>
                    <p className="contact-second-p" data-aos="zoom-in-left">Mantri Commercio - Spatium Tower A, Sy No 51/2, 51/3, 51/4, Of Devarabeesanahalli Village And Hjem 39/5 Of Kariyammana Agrahara Village Varthur Hobli, Bangalore East Taluk, Bangalore.</p>
                 </div>
                </div>
            </div>
        </div>
        </>
    )
}
export default Contact