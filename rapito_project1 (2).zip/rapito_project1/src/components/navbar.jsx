import {BrowserRouter,Route,Routes,Link} from 'react-router-dom'
import Home from './home'
import About from './About' 
import Safty from './safty'
import Blog from './blog'
import Contact from './contact'
import Download from './download'
function Navbar(){
  return (
    <>
    <BrowserRouter>
            <nav className="navbar navbar-expand-lg  navbar-light bg-warning ">
            <div className="container">
  <h3 className="navbar-brand" href="#">Rapido</h3>
  <button className="navbar-toggler" type="button" data-bs-target="#navbarNav" data-bs-toggle="collapse" aria-controls="navbarNav" 
        aria-expanded="false" 
        aria-label="Toggle navigation">
    <span className='navbar-toggler-icon'></span>
  </button>
  <div className="collapse navbar-collapse justify-content-center"
          id="navbarNav" >
    <ul className="navbar-nav ms-auto">
      <li className="nav-item active">
        <Link to="/" className="nav-link">Home</Link>
      </li>
      <li className="nav-item active">
        <Link to="/about" className="nav-link">About Us</Link>
      </li>
       <li className="nav-item active">
        <Link to="/safty" className="nav-link">Safty Us</Link>
      </li>
       <li className="nav-item active">
        <Link to="/blog" className="nav-link">Blog</Link>
      </li>
         <li className="nav-item active">
        <Link to="/Contact" className="nav-link">Contact Us</Link>
      </li>
      
    </ul>
  </div>
  <div className="collapse navbar-collapse justify-content-end" id="...">
  <ul className="navbar-nav">
        <Link to="/download" className="nav-link"><button className='btn btn-download'>Download App</button></Link>
      
  </ul>
</div>
  </div>
</nav>
    <Routes>
      <Route path="/" element ={<Home/>}></Route>
      <Route path="/about" element ={<About/>}></Route>
      <Route path="/safty" element ={<Safty/>}></Route>
      <Route path="/blog" element ={<Blog/>}></Route>
      <Route path="/contact" element ={<Contact/>}></Route>
      <Route path="/download" element ={<Download/>}></Route>

    </Routes>
    </BrowserRouter>
    
    </>
  )
}
export default Navbar