import saftyride1 from '../assets/saftyride.avif';
import saftyride2 from '../assets/saftyride.jpg';
import saftyride3 from '../assets/saftyride2.avif';
import secondsafty from '../assets/saftyimg1.jpeg'
import secondsafty1 from '../assets/saftyimg2.png'
import "aos/dist/aos.css"
import { useEffect } from 'react';
import AOS from "aos";

function Secondimg({img,content,para,button}){
    return(
        <>
 
  <div className="saftydiv">
  <img src={img} alt="" className="card-img" data-aos="fade-up"
     />
  <div className="card-body">
    <h1 className='p-5'data-aos="fade-down" >{content}</h1>
    <p className='saftypara1'data-aos="fade-down">{para}</p>
    <button className='btn btn-safty1'data-aos="fade-down">{button}</button>
  </div>
</div>     
        </>
    )
}
export function Secondsafty(){
    const Secondimg1=[
     {
        img:secondsafty,
        content:"For captions",
        para:"From hiring to training to monitoring to ongoing checks,we take all necessary steps to ensure our captains safty",
        button:"Know more"
     },
      {
        img:secondsafty1,
        content:"For customers",
        para:"Every ride is tracked latitudinal and langitudial data.",
        button:"Know more"
     }
    ]
    return (
        <>
        {Secondimg1.map((item,index)=> (<Secondimg key={index} img={item.img} content={item.content} para={item.para} button={item.button}/>))}
        </>
    );
}
function ImageItem({ img }) {
  return <img src={img} alt="Safety Ride" className='saftyimg'/>;
}
export function SaftyInner() {
  const Images = [
    { img: saftyride1 },
    { img: saftyride2 },
    { img: saftyride3 },
  ];

  return (
    <>
      {Images.map((item, index) => (
        <ImageItem key={index} img={item.img} />
      ))}
    </>
  );
}

function Safty(){
   useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true,
    });
  }, []);
    return(
        <>
        <div className="container-fluid-lg mx-5">
            <div className="row justify-content-center mt-5">
                <div className=" col-12 col-md-5 m-2  "  data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
                   <div className="container-item safty-container">
                          <h1 className="saftyh1">Safty For All</h1>
                          <p className="sapara">At Rapido,the well-being our customers is above everything else.We are costanly in pursuit of enhancing our safty measures to ensure every Rapito ride is a pleasant and comfortable experience.</p>
                   </div>
                </div>
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item">
                        <SaftyInner/>
                   </div>
                </div>
            </div>
            
        </div>
        <div className='container safty1-container'>
        <div className="row ">
                <h1 className='saftyh12'data-aos="fade-right">Covers Everyone</h1> 
                    <Secondsafty/> 
            </div>
        </div>
       <div className='container safty3 overflow-hidden'data-aos="flip-left">
              <div className="container-fluid-lg mx-5 safty-container-scond "data-aos="zoom-in-up">
            <div className="row justify-content-center mt-5" >
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
                       <i class="fa-solid fa-handshake fa-safy-icon"></i>
                       <h2 className='h2'>
                        Measures to ensure the well-being of both,our captains and customers.
                       </h2>
                   </div>
                </div>
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
                       <i class="fa-solid fa-umbrella fa-safy-icon"></i>
                       <h2 className='h2'>Insurance</h2>
                       <p className='safty-para2'> Insurence can be claimed for any accident that occurs during the ride covering OPD treatment,hospitalisa,-tion,and accidental benefit with a maximum sum insured of Rs.5 Lakh.It can be claimed as soon as the ride.</p>
                   </div>
                </div>
            </div>
            <div className="row justify-content-center mt-5">
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
                      <i class="fa-solid fa-user-tie fa-safy-icon"></i>
                       <h2 className='h2'>24 X 7 Customer Support
                       </h2>
                       <p className='safty-para2'>Both,our captains and customers can report any kind of issues to Rapido through the 24 x 7 support feature on the app post & during the ride.   </p>
                   </div>
                </div>
                <div className=" col-12 col-md-5 m-2  " >
                   <div className="container-item safty-container">
                       <i class="fa-solid fa-star fa-safy-icon"></i>
                       <h2 className='h2'>Two-way Rating System</h2>
                       <p className='safty-para2'> Post the ride,both parties can give a rating to each other and any rating below 3 is flogged from Rapido's end.Rapido reaches out to them in 10 minutes to address their concern.the captain is terminated immediately in case of any misconduct.</p>
                   </div>
                </div>
            </div>
        </div>
        
       </div>


        </>
        
    )
}
export default Safty