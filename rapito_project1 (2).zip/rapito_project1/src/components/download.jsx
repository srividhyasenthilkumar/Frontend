import imgapp1 from '../assets/rapido-app.jpeg'
import imgapp2 from '../assets/logo.png'
import "aos/dist/aos.css"
import { useEffect } from 'react';
import AOS from "aos";
function Download(){
   useEffect(() => {
        AOS.init({
          duration: 1000,
          once: true,
        });
      }, []);
  return (
    <>
    <div className="download-div" data-aos="zoom-in-left" >
            <div className="container-fluid-lg mx-5" >
            <div className="row justify-content-center mt-5" >
                <div className=" col-12 col-md-5 m-2 dow-div "data-aos="zoom-in-right" data-aos-duration="3000" style={{overflow:"hidden"}}>
                     <h4 className='download-h4'>Captain App Download</h4>
                     <img src={imgapp1} alt="" className='download-img'/>
                     <h5 className='download-h5' data-aos="zoom-in-up">Android</h5>
                </div>
                <div className=" col-12 col-md-5 m-2  " style={{overflow:"hidden"}}data-aos="zoom-in-left" data-aos-duration="3000">
                   <h4 className='download-h4' >Customer App Download</h4>
                   <img src={imgapp2} alt=""  className='download-img'/>
                   <h5 className='download-h5' data-aos="zoom-in-up" style={{overflow:"hidden"}}>Android/IOS</h5>
                </div>
              </div>
            </div>
    </div>
    </>
  )
}
export default Download