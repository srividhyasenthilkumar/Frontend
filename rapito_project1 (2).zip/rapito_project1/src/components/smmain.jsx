
import Navbar from "./navbar";
import person1 from '../assets/person1.jpeg'
import person2 from '../assets/person2.jpeg'
import person3 from '../assets/person3.jpeg'
import About, { Aboutchild } from "./About";

function App1(){
    return (
        <>
        
        <Navbar/>
         <Aboutchild/>
        </>
    )
}
export default App1

export function Service(){
    return{

    }
}





// export function Aboutimage(){
//     const Image=[
//         {
//             image1 :ride1
//         },
//         {
//             image2 :ride2
//         }
//     ]
//     const images = Image.map((item, index) => (
//     <About key={index} image1={item.image1} />
//   ));
//     return(
// <>  {images }</>
//     )
// }
// export function Aboutimage(){
//     const image=[
//         {
//             img:person1,
//             name:"ragul"
//         },
//         {
//             img:person2,
//             name:"sri"
//         },
//         {
//             img:person3,
//             name:"sriv"
//         }
//     ]
//     const images= image.map((item,index)=>(<About key={index} img={item.img} name={item.name}/>))
//     return(
//         <>
//         {images}
//         </>
//     )
// }
