//api.openweathermap.org/data/2.5/weather?q={city}&appid={API key}&units=imperial
const API_KEY = "6c91171e036097303d934b3b6ba3c712";

const getWeatherData = (city) => {
    const URL = 'https://api.openweathermap.org/data/2.5/weather';
    const Full_URL = `${URL}?q=${city}&appid=${API_KEY}&units=imperial`;
    return fetch(Full_URL)
        .then((response) => {
            if (!response.ok) {
                throw new Error(`City not found: ${city}`);
            }
            return response.json();
        });
};

function searchCity() {
    const city = document.getElementById('city-input').value;
    getWeatherData(city)
        .then((response) => {
            showWeatherData(response);
        })
        .catch((err) => {
            console.error(err);
            alert(err.message);
        });
}

const showWeatherData = (weatherData) => {
    document.getElementById('city-name').innerText = weatherData.name;
    document.getElementById('weather-type').innerText = weatherData.weather[0].main;
    document.getElementById('temp').innerText = weatherData.main.temp;
    document.getElementById('min-temp').innerText = weatherData.main.temp_min;
    document.getElementById('max-temp').innerText = weatherData.main.temp_max;


};
